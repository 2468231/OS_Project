import React,{Component} from 'react';
import Layout from './components/Dashboard/Dashboard';
import './App.css';

class App extends Component{
  render(){
    return (
      <Layout></Layout>
    )
  }
}


export default App;
